<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CadastraOportunidadeController extends Controller
{
    function Index(Request $request) {
        // Retorna os dados em formato JSON
        echo $request;
    }
}
